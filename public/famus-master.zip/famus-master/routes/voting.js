var express = require('express');
var router = express.Router();
var Parse = require('parse/node').Parse;
var multer  = require('multer');
var crypto = require('crypto');

var path = require('path');

Parse.initialize("8Nx1MZhNZzI6jw1SM73isCHpmGGIPBvx0OQTJJl3","jU9dbSvBPVQLHD9saDx4PU7FNvqUkxZLCYFgLLpq");

/* GET users listing. */
console.log("about to get");

/* voteResult has the result of the user's vote */
router.get('/getVote/:userID/:recordingID/upVote', function(req, res, next) {
	var vote = Parse.Object.extend("VotingObject");
	var voteObj = new vote();
	var query = new Parse.Query(vote);
	var userID = req.params.userID; 
	var recordingID = req.params.recordingID;
	var objectID; 
	var voteResult;  /* this is the result of the url*/
	var object;	//to store the found object with userID
	console.log("vote object and ID retrieved");
	console.log("userID:" + userID);
	console.log("recordingID:" + recordingID);
	query.equalTo("UserID", userID);
	query.equalTo("recordingID", recordingID);
	console.log(query);
	query.find({
  		success: function(results) 
  		{
        	object = results[0];
        	objectID = object.id;
        	console.log("object id: " + object.id);
      		console.log("object successfully retrieved ");
      		console.log('upVote: ');
      		showID();
  		}
	});
	var showID = function()
	{
		console.log(objectID + " is here");
		var getvote = Parse.Object.extend("VotingObject");
		var queryGetVote = new Parse.Query(getvote);
		queryGetVote.get(objectID, 
		{
  			success: function(voteObj) 
  			{
    			// The vote Object was retrieved successfully.
    			console.log(userID + " object successfully retrieved ");
    			voteResult = voteObj.get("upVote");
    			console.log(voteResult);
    			report();
  			},
  			error: function(object, error) 
  			{
    			// The object was not retrieved successfully.
    			// error is a Parse.Error with an error code and message.
  			}
		});
	}	
	var report = function()
	{
		res.send(userID + "'s upVote to recording " + recordingID + " is " + voteResult);
	}
});


console.log("before newrecord!");
router.post('/send', function (req, res) {
  	// req.file is the `avatar` file
  	// req.body will hold the text fields, if there were any
  	//console.log(req.file);
	var title = req.body.title;
  	var userID = req.body.userID;
  	var recordingID = req.body.recordingID
  	var upVote = req.body.upVote;
  	var downVote =  req.body.downVote;
  	var description = req.body.description;
  	console.log(req.body);
  	console.log("inside post");
  	console.log('title:' + title + ', recordingID:' + recordingID + ', description:' + description+', userID:' +userID + ', upVote:' + upVote + ', downVote:'+downVote);
  	var VotingObject = Parse.Object.extend("VotingObject");
  	var voteInstance = new VotingObject();
  	console.log("voting instance created!");
  	voteInstance.set("title", title);
  	voteInstance.set("UserID", userID);
  	voteInstance.set("recordingID", recordingID);
  	voteInstance.set("upVote", upVote);
  	voteInstance.set("downVote", downVote);
  	voteInstance.set("description", description);
  	console.log("instance set up");
  	voteInstance.save(null, {
    	success: function(voteInstance) {
        	console.log("success!!!");
        	res.status(200).end();
    	},
    	error : function(voteInstance, error) {
    		console.log(error);
      		res.status(403).end();
    	}
  	});
  	res.status(200).end();
  	// res.send('OK');
});


module.exports = router;
