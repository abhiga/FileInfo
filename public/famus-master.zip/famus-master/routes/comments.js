var express = require('express');
var router = express.Router();
var Parse = require('parse/node').Parse;
var multer  = require('multer');
var upload = multer({ dest: 'uploads/' });

Parse.initialize("8Nx1MZhNZzI6jw1SM73isCHpmGGIPBvx0OQTJJl3","jU9dbSvBPVQLHD9saDx4PU7FNvqUkxZLCYFgLLpq");

router.post('/postComments', function(req, res){ 
	//This only supports comments on recordings not comments on comments
	var commentsID = req.body.commentsID;
	var objectID = req.body.objectID;
	var comments = req.body.comments; //Can be different depends
	
	var RecordingObject = Parse.Object.extend("RecordingObject");
	var query = new Parse.Query(RecordingObject);
	query.get(objectID, {
		success: function(matchedObj) {
		},
		error: function(matchedObj, error) {
			res.status(404);
			res.send("Specified recording not found!").end();
		}
	});

	var CommentObject = Parse.Object.extend("CommentObject");
	var commentTable = new CommentObject();
	commentTable.save({commentsID: commentsID, comments: comments,
		objectID: objectID}, {
		success: function(obj) {
			console.log("Comments posted!");
			res.status(200).end();
		},
		error: function(obj, error) {
			console.log(error);
			res.status(403).end();
		}
	});
	res.status(200).end();
});

router.get('/getComments', function(req, res, next) {
	var objectID = req.body.objectID;

	var CommentObject =  Parse.Object.extend("CommentObject");
	var query = new Parse.Query(CommentObject);
	query.find({
		success: function(results) {
			for(var i = 0; i < results.length; i++) {
				console.log('The comment is: ' + results[i].get('comments'));
			}
			res.send(results);
		},
		error: function(error) {
			res.status('404');
			res.send('error');
		} 
	});
	
});



module.exports = router;